package com.shipco.phoenix.security.spring.saml;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;

public class SavedRequestAwareAuthenticationSuccessHandlerDefault
		extends SavedRequestAwareAuthenticationSuccessHandler {

	String defaultURL;
	@Override
	protected String determineTargetUrl(HttpServletRequest request, HttpServletResponse response) {
		String targetUrl= super.determineTargetUrl(request, response);
		return targetUrl.replace("http://", "https://").replace(":80", "");
	}

	@Override
	public void setDefaultTargetUrl(String defaultTargetUrl) {
		
	}
}
