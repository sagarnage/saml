package com.shipco.phoenix.security.common.constants;

public class TokenConstants {

	public static final String SECRET_TOKEN =  "073C1041-403B-46D7-927B-DCA069238580";
}
