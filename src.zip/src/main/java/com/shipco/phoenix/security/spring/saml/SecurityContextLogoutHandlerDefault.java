package com.shipco.phoenix.security.spring.saml;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

public class SecurityContextLogoutHandlerDefault extends SecurityContextLogoutHandler{
	
    public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
    	Cookie logoutCookie = new Cookie("ADFSLoggedOut", "true");
    	logoutCookie.setPath("/");
        response.addCookie(logoutCookie);
        super.logout(request, response, authentication);
    }
}
