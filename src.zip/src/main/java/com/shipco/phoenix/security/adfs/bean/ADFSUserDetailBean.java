package com.shipco.phoenix.security.adfs.bean;

import java.util.HashMap;

public class ADFSUserDetailBean {

	private static HashMap<String, ADFSUserAttributesBean> attributeMap = new HashMap<String, ADFSUserAttributesBean>();

	public static HashMap<String, ADFSUserAttributesBean> getAttributeMap() {
		return attributeMap;
	}

	public static void setAttributeMap(HashMap<String, ADFSUserAttributesBean> userAttributeMap) {
		attributeMap = userAttributeMap;
	}

}
