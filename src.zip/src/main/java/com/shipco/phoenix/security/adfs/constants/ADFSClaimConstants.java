package com.shipco.phoenix.security.adfs.constants;

public class ADFSClaimConstants {

	public static final String PASSWORD_LAST_SET ="pwdLastSet" ;
	public static final String ACCOUNT_EXPIRES ="accountExpires" ;

}
