package com.shipco.phoenix.security.common.constants;

public class ContextConstants {

	public static final String PHOENIX_APPLICATION_CONTEXT =  "/phoenix";
	public static final String SECURITY_MODEL_CONTEXT =  "security/";
	public static final String SECURITY_MODEL_SAML_SERVLET_CONTEXT =  "/saml/";

}
