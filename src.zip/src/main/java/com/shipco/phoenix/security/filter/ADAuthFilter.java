package com.shipco.phoenix.security.filter;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


public class ADAuthFilter
  implements Filter
{
  HashMap<String, String> cookies = new HashMap();
  private final Logger log = Logger.getLogger(ADAuthFilter.class);
  
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
    throws IOException, ServletException
  {
	  
    this.log.info("ADFS filter invoked");
    String url = ((HttpServletRequest)request).getRequestURL().toString();
    this.log.info("ADFS filter invoked : " + url);
    HttpServletRequest httpRequest = (HttpServletRequest)request;
    HttpServletResponse httpResponse = (HttpServletResponse)response;
    if (!url.contains("/saml/"))
    {
    	if(httpRequest.getRequestURI().endsWith("html") ||httpRequest.getRequestURI().endsWith("jsp")) {
			log.debug("skipping adfs auth for static files and jsp pages");
			filterChain.doFilter(request, response);
			return;
	}
      this.log.info("redirecting to saml");
    //  String redirectUrl = "https://scan-it.phxcloud.io/security/minor-release-1/35.33//saml/";
      String redirectUrl =url.replaceAll("http", "https").replaceAll("80:", "")+"/saml/";
      httpResponse.sendRedirect(redirectUrl);
    }
    else
    {
      this.log.info("not redirecting to saml");
      filterChain.doFilter(request, response);
    }
  }
  
  public void destroy() {}
  
  public void init(FilterConfig filterConfig)
    throws ServletException
  {}
}
