package com.shipco.phoenix.security.adfs.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shipco.phoenix.security.adfs.bean.ADFSClaimsBean;
import com.shipco.phoenix.security.common.util.CryptoUtil;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.opensaml.saml2.core.Attribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLCredential;

public class SamlServlet
  extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  private Logger logger = Logger.getLogger(getClass());
  
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
  {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    ADFSClaimsBean aDFSClaims = new ADFSClaimsBean();
    SAMLCredential credential = (SAMLCredential)authentication.getCredentials();
    List<Attribute> attributeValues = credential.getAttributes();
    for (Attribute attribute : attributeValues) {
      if (attribute.getName().equalsIgnoreCase("pwdLastSet")) {
        aDFSClaims.setPwdLastSet(credential.getAttributeAsString(attribute.getName()));
      } else if (attribute.getName().equalsIgnoreCase("accountExpires")) {
        aDFSClaims.setAccountExpires(credential.getAttributeAsString(attribute.getName()));
      }
    }
    req.getSession().setAttribute("isAuthenticated", "true");
    ObjectMapper mapper = new ObjectMapper();
    String jsonCookie = mapper.writeValueAsString(aDFSClaims);
    String baseUrl = req.getRequestURL().toString();
  /*  String baseUrl = req.getRequestURL().toString().replaceAll("http://", "https://");
    String redirectUrl = baseUrl.substring(0, baseUrl.indexOf("security/minor-release-1/35.33/"));
    */
    Cookie userCookie = new Cookie("USERNAME", authentication.getName());
    userCookie.setPath("/");
    resp.addCookie(userCookie);
    
    Cookie adfsCookie = new Cookie("ADFS", "true");
    adfsCookie.setPath("/");
    resp.addCookie(adfsCookie);
    try
    {
      Cookie claimsCookie = new Cookie("CLAIMS", CryptoUtil.encrypt("073C1041-403B-46D7-927B-DCA069238580", jsonCookie));
      claimsCookie.setPath("/");
      resp.addCookie(claimsCookie);
    }
    catch (InvalidKeyException|NoSuchAlgorithmException|InvalidKeySpecException|NoSuchPaddingException|InvalidAlgorithmParameterException|IllegalBlockSizeException|BadPaddingException e)
    {
      e.printStackTrace();
    }
    
    Cookie logoutCookie = new Cookie("ADFSLoggedOut", "false");
    logoutCookie.setMaxAge(0);
    logoutCookie.setPath("/");
    resp.addCookie(logoutCookie);
    baseUrl= baseUrl.replaceAll("http", "https").replaceAll("80:", "").replaceAll("security", "phoenix").replaceAll("/saml/", "");
    resp.sendRedirect(baseUrl);
    // resp.sendRedirect("https://scan-it.phxcloud.io/phoenix/minor-release-1/35.33/");
  }
}
