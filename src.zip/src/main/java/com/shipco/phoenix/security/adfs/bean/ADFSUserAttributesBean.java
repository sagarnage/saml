package com.shipco.phoenix.security.adfs.bean;

import java.util.HashMap;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLCredential;

public class ADFSUserAttributesBean {

	private Authentication authentication;
    private SAMLCredential credential ;
    private HashMap<String, String> claimsMap = new HashMap<>();
    public HashMap<String, String> getClaimsMap()  {
		return claimsMap;
	}
	public void setClaimsMap(HashMap<String, String> claimsMap) {
		this.claimsMap = claimsMap;
	}
	public Authentication getAuthentication() {
		return authentication;
	}
	public void setAuthentication(Authentication authentication) {
		this.authentication = authentication;
	}
	public SAMLCredential getCredential() {
		return credential;
	}
	public void setCredential(SAMLCredential credential) {
		this.credential = credential;
	}
	public String getAssertion() {
		return assertion;
	}
	public void setAssertion(String assertion) {
		this.assertion = assertion;
	}
	private String assertion;
	
}
