package com.shipco.phoenix.security.spring.saml;

import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.saml.metadata.MetadataGenerator;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;

public class MetadataGeneratorFilterDefault extends MetadataGeneratorFilter {

	public MetadataGeneratorFilterDefault(MetadataGenerator generator) {
		super(generator);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected String getDefaultBaseURL(HttpServletRequest request) {
		// TODO Auto-generated method stub
		/*String url = */return super.getDefaultBaseURL(request);
		//return url.replace("http://", "https://").replace(":80", "");
	}

}
