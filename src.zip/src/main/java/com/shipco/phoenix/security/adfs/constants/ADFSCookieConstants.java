package com.shipco.phoenix.security.adfs.constants;

public class ADFSCookieConstants {
	public static final String USERNAME ="USERNAME" ;
	public static final String ADFS ="ADFS" ;
	public static final String CLAIMS ="CLAIMS" ;



}
