package com.shipco.phoenix.security.adfs.bean;

public class ADFSClaimsBean {

	private String pwdLastSet;
	private String accountExpires;
	public String getPwdLastSet() {
		return pwdLastSet;
	}
	public void setPwdLastSet(String pwdLastSet) {
		this.pwdLastSet = pwdLastSet;
	}
	public String getAccountExpires() {
		return accountExpires;
	}
	public void setAccountExpires(String accountExpires) {
		this.accountExpires = accountExpires;
	}
}
