package com.shipco.phoenix.security.adfs.bean;

import org.opensaml.Configuration;
import org.opensaml.xml.security.BasicSecurityConfiguration;
import org.opensaml.xml.signature.SignatureConstants;
import org.springframework.beans.factory.InitializingBean;

public class SAMLConfigurationBean implements InitializingBean {

	   private String signatureAlgorithm ;
	    private String digestAlgorithm;

	    public void setSignatureAlgorithm(String algorithm) {
	        switch (algorithm) {
	            case "SHA256" :
	                signatureAlgorithm = SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256;
	                digestAlgorithm = SignatureConstants.ALGO_ID_DIGEST_SHA256;
	                break;
	            case "SHA512" :
	                signatureAlgorithm = SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA512;
	                digestAlgorithm = SignatureConstants.ALGO_ID_DIGEST_SHA512;
	                break;
	            default:
	                signatureAlgorithm = SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA1;
	                digestAlgorithm = SignatureConstants.ALGO_ID_DIGEST_SHA1;
	        }
	    }

	    @Override
	    public void afterPropertiesSet() throws Exception {
	        BasicSecurityConfiguration config = (BasicSecurityConfiguration) Configuration.getGlobalSecurityConfiguration();
	        config.registerSignatureAlgorithmURI("RSA", signatureAlgorithm);
	        config.setSignatureReferenceDigestMethod(digestAlgorithm);
	    }
}